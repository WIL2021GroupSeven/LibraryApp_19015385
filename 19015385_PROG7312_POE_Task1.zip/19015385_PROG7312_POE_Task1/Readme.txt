1. Run the application
2. Select the available button on the home screen 
3. Click the Generate Random button 
4. Once all Call Numbers are displayed, drag and drop your selected Call Number to the empty list box in ascending order. 
5. The How To Play Button Explains further. 